# Level 2: Multi-Agent Analytics Assistant

A Multi-Agent Analytics Assistant using CrewAI, Ollama, Streamlit, Function Tools, and a Local MCP Server. 

## Folder Structure
Ensure your repository matches this structure:
```text
level_2_multi_agent_mcp_project/
├── app.py
├── requirements.txt
├── README.md
├── config/
│   ├── agents.yaml
│   └── tasks.yaml
├── agents/
│   ├── supervisor_agent.py
│   ├── data_analyst_agent.py
│   └── data_scientist_agent.py
├── function_tools/
│   ├── supervisor_tools.py
│   ├── analyst_tools.py
│   └── scientist_tools.py
├── mcp_server/
│   ├── server.py
│   └── sample_data/
│       └── events_sample.csv